import { Component, OnChanges, OnInit, Input, ViewChild, ViewContainerRef, OnDestroy } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient, HttpResponse, HttpEventType, HttpHeaderResponse } from '@angular/common/http';
import { ActivatedRoute, Params, Router, NavigationExtras } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder, NgForm } from '@angular/forms';
import { Observable, Subscription, throwError, of, empty } from 'rxjs';
import { Base64 } from 'js-base64';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../environments/environment';
import { TaskService } from '../task.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CookieService } from 'ngx-cookie-service';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonUserAccess } from '../common.service';
import { DatafilterPipe } from '../datafilter.pipe';

@Component({
    selector: 'app-task',
    templateUrl: './task.component.html',
    styleUrls: ['./task.component.css'],
})
export class TaskComponent implements OnInit {
    rForm: FormGroup;
    stringparseDashAuthData;
    stringparseDashTkidData;
    singleUserData: any;
    public filterQuery = '';
    journalStatus;
    data: any[];
    hideForLocalUser: Boolean = false;
    storeUpdatedVal;
    showHistory: Boolean = false;
    accessAuthorizedUser: Boolean = true;
    selectedFile: File;
    userSelectFile: Boolean;
    userUploadFile: Boolean;
    setCommentCount;
    commentVal: any;
    passJournalStatus;
    navigationExtrasdash;
    text;
    valDecodeParameter: any;
    downloadArticleFile;
    fileObject;
    fileStyleObject;
    fileReferenceObject;
    fileName;
    fileUrl;
    fileStyleName;
    fileStyleUrl;
    fileReferenceName;
    fileReferenceUrl;
    @ViewChild('fileInput') fileInput;
    submitCompletedTaskObj: any;
    journalLockStatus: Boolean = false;
    hideForLockUser = true;
    checkIfOthersAreSelected;
    fileNotFound: Boolean = false;
    hideForSubmitJournal: Boolean = false;
    statusAlreadyTaken: Boolean = false;
    hideOkLockuser: Boolean = true;
    hideSaveJobAlreadyTaken: Boolean = true;
    userGotLocked: Boolean = false;
    showLockUserResponse;
    hideUnauthorisedUser: Boolean;
    showChangesSpecial;
    changesAccess;
    storeInstrDetail;
    sub: Subscription;
    lockUserNameCheck;
    checkedOrNot: Number = 1;
    preEditUserOnlyShow: Boolean;
    downloadNoContentDisposition: any;
    styleNoContentDisposition: any;
    referenceNoContentDisposition: any;
    fileNotFoundServer: Boolean = false;
    public rowsOnPage = 10;
    public sortBy = 'email';
    public sortOrder = 'asc';
    unCheckLockUser;
    storeSingleTaskIdData: any;
    journalDisplayStatus: any;
    disabledSelectedCheckbox = false;
    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private _pass: TaskService,
        private http: HttpClient,
        private toastrService: ToastrService,
        private fb: FormBuilder,
        config: NgbModalConfig,
        private modalService: NgbModal,
        private cookieService: CookieService,
        private sanitizer: DomSanitizer,
        private _spec: CommonUserAccess,
        private spinner: NgxSpinnerService,
    ) { }

    ngOnInit() {
        this.spinner.show();
        this.rForm = this.fb.group({
            'comment': [null, Validators.required],
            'upload': [null, Validators.required],
            'journalStatus': [null, Validators.required],
        });
        this.valDecodeParameter = JSON.parse(this.cookieService.get('token'));
        this.singleUserData = JSON.parse(this.cookieService.get('singleArt'));
        this.journalStatus = [];

        // arg object for Download only

        const fileStatusFlag = new Object();
        fileStatusFlag['Jcode'] = this.singleUserData['Jcode'];
        fileStatusFlag['ArtID'] = this.singleUserData['ARTID'];
        fileStatusFlag['Taskname'] = this.singleUserData['TaskName'];

        this._pass.downloadJournalForm(fileStatusFlag, this.valDecodeParameter).subscribe((res: any) => {
            this.fileObject = res;
            const keys = this.fileObject.headers.get('content-disposition');
            if (keys === null) {
                this.downloadNoContentDisposition = keys;
                console.log(this.downloadNoContentDisposition, 'this.fileStyleObject');
            } else {
            this.fileName = keys.replace('attachment; filename=', '');
            const blob = new Blob([this.fileObject.body], { type: 'application/octet-stream' });
            this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
            }
        });


        // arg object for Style Guide and Reference
        const fileStyleGuide = new Object();
        fileStyleGuide['Jcode'] = this.singleUserData['Jcode'];
        fileStyleGuide['Taskname'] = this.singleUserData['TaskName'];
        this._pass.styleJournalForm(fileStyleGuide, this.valDecodeParameter).subscribe({
            next: res => {
                this.fileStyleObject = res;
                console.log(this.fileStyleObject, 'this.fileStyleObject');
                const keys = this.fileStyleObject.headers.get('content-disposition');
                if (keys === null) {
                    this.styleNoContentDisposition = keys;
                    console.log(this.styleNoContentDisposition, 'this.fileStyleObject');
                } else {
                console.log(keys, 'blob this.fileStyleUrl');
                this.fileStyleName = keys.replace('attachment; filename=', '');
                const blob = new Blob([this.fileStyleObject.body], { type: 'application/octet-stream' });
                this.fileStyleUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
                }
            },
            error: error => {
                console.error(error, 'err');
            },
            complete: () => console.log('done')
        }
        //     (res: any) => {
        //     this.fileStyleObject = res;
        //     console.log(this.fileStyleObject, 'this.fileStyleObject');
        //     const keys = this.fileStyleObject.headers.get('content-disposition');
        //     this.fileStyleName = keys.replace('attachment; filename=', '');
        //     const blob = new Blob([this.fileStyleObject.body], { type: 'application/octet-stream' });
        //     this.fileStyleUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
        // }
        );

        // arg object for Style Guide and Reference
        const fileReference = new Object();
        fileReference['Jcode'] = this.singleUserData['Jcode'];
        fileReference['Taskname'] = this.singleUserData['TaskName'];
        this._pass.referenceJournalForm(fileReference, this.valDecodeParameter).subscribe((res: any) => {
            this.fileReferenceObject = res;
            const keys = this.fileReferenceObject.headers.get('content-disposition');
            if (keys === null) {
                this.referenceNoContentDisposition = keys;
                console.log(this.referenceNoContentDisposition, 'this.fileStyleObject');
            } else {
            this.fileReferenceName = keys.replace('attachment; filename=', '');
            const blob = new Blob([this.fileReferenceObject.body], { type: 'application/octet-stream' });
            this.fileReferenceUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
            }
        });

        console.log(this.singleUserData, 'this.singleUserData');
        this.submitCompletedTaskObj = new Object();
        this.submitCompletedTaskObj['TaskID'] = this.singleUserData['TaskID'];
        this.submitCompletedTaskObj['Username'] = this.singleUserData['Username'];
        this.submitCompletedTaskObj['Workname'] = this.singleUserData['Workname'];
        this.submitCompletedTaskObj['TaskName'] = this.singleUserData['TaskName'];
        this.submitCompletedTaskObj['ArtComments'] = '';
        this.submitCompletedTaskObj['StatusFlag'] = '';


        const specInfoDetail = new Object();
        specInfoDetail['Jcode'] = this.singleUserData['Jcode'];
        specInfoDetail['ARTID'] = this.singleUserData['ARTID'];
        specInfoDetail['TaskName'] = this.singleUserData['TaskName'];
        this._pass.specialInstruction(this.valDecodeParameter, specInfoDetail).subscribe({
            next: data => {
                this.showChangesSpecial = data;
                console.log(this.showChangesSpecial, 'sp');
            },
            error: error => {
                console.error(error, 'err');
            },
            complete: () => console.log('done')
        });

        this.storeInstrDetail = this.valDecodeParameter['UserName'];
        if (this.storeInstrDetail === 'FC_test') {
            this.hideUnauthorisedUser = false;
            this.accessAuthorizedUser = false;
        } else {
            this.accessAuthorizedUser = true;
            this.hideUnauthorisedUser = true;
        }
        this._spec.commonUserAccess().subscribe(res => {
            this.changesAccess = res['User'];
            console.log(this.changesAccess, 'res user');
            if (this.changesAccess[0].name === this.storeInstrDetail[0]) {
                this.hideForLocalUser = false;
            } else {
                this.hideForLocalUser = true;
            }
        });
//         this.lockUserNameCheck = localStorage.getItem('lockuser');
// console.log(typeof this.lockUserNameCheck, this.lockUserNameCheck, 'this.lockUserNameCheck');
//         if (this.lockUserNameCheck === 'true') {
//            console.log(this.valDecodeParameter, this.submitCompletedTaskObj, 'test');
//             this._pass.lockJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe({
//                 next: data => {
//                     console.log(data);
//                 },
//                 error: error => {
//                     console.log(error);
//                 },
//                 complete: () => console.log('completed')
//             });
//             this.unCheckLockUser.checked = true;
//             console.log(this.unCheckLockUser, 'unCheckLockUser this.lockUserNameCheck');
//         }


        //  show user pass dash data

            this.sub = this._pass.userPassDashData(this.valDecodeParameter, this.singleUserData).subscribe({
                next: data => {
                this.storeSingleTaskIdData = JSON.parse(data.toString());
                for (let i = 0; i < this.storeSingleTaskIdData.length; i++) {
                    const singleUserStatus = this.storeSingleTaskIdData[i].Status;
                    if (singleUserStatus === 'WP') {
                        const unCheckLockUser = <HTMLInputElement>document.getElementById('changelock');
                        unCheckLockUser.checked = true;
                        this.journalDisplayStatus = singleUserStatus;
                    } else {
                        this.journalDisplayStatus = singleUserStatus;
                    }
                }
            },
            error: error => {
                console.log(error);
            },
            complete: () => console.log('completed'),
        });



        // show and hide 'Not required for copyediting'
        if (this.singleUserData['Workname'] === 'PeerReview') {
            this.preEditUserOnlyShow = true;
            console.log(this.checkedOrNot, 'this.checkedOrNot checked');
            this.submitCompletedTaskObj['CPYCheck'] = this.checkedOrNot;
            console.log('peerReview');
        } else {
            this.preEditUserOnlyShow = false;
            console.log(this.checkedOrNot, 'this.checkedOrNot not checked');
            this.submitCompletedTaskObj['CPYCheck'] = this.checkedOrNot;
            console.log('other user');
        }
        console.log(this.valDecodeParameter, this.submitCompletedTaskObj, 'single user data');

        this._pass.lockJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe((data) => {
            console.log(data, 'data changes');
        });


        this.spinner.hide();
    }
    isFieldValid(field: string) {
        return !this.rForm.get(field).valid && this.rForm.get(field).touched;
    }
    displayFieldCss(field: string) {
        return {
            'has-error': this.isFieldValid(field),
            'has-feedback': this.isFieldValid(field)
        };
    }

    updateSelectedValue(event: string): void {
        console.log(event);
        this.journalStatus = ['Complete', 'InComplete', 'Hold'];
        this.storeUpdatedVal = event;
        const otherCheckbox = document.querySelector('input[value="preeditingOnlyId"]');
        console.log(otherCheckbox, 'otherCheckbox');
        const checkCopyEditingCompleted = <HTMLInputElement>document.getElementById('preeditingOnlyId');
        if (this.storeUpdatedVal === 'Complete') {
            checkCopyEditingCompleted.checked = false;
            this.setCommentCount = 1;
            this.disabledSelectedCheckbox = false;
        } else if (this.storeUpdatedVal === 'InComplete') {
            checkCopyEditingCompleted.checked = false;
            this.setCommentCount = 2;
            this.disabledSelectedCheckbox = true;
        } else if (this.storeUpdatedVal === 'Hold') {
            checkCopyEditingCompleted.checked = false;
            this.setCommentCount = 3;
            this.disabledSelectedCheckbox = true;
        }
    }
    showOnlyHistory() {
        this.showHistory = !this.showHistory;
        this._pass.userPassDashData(this.valDecodeParameter, this.singleUserData).subscribe({
            next: data => {
                const body = data;
                const userPassDashDataSub = JSON.parse(body.toString());
                this.data = userPassDashDataSub;
            },
            error: error => {
                console.error(error, 'err');
            },
            complete: () => console.log('done')
        });
    }

    onFileChanged(event) {
        console.log(event, 'ie');
        this.selectedFile = event.target.files[0];
        this.userSelectFile = false;
        this.userUploadFile = true;
    }

    onSubmit(content) {
        const newPropObj = this.setCommentCount;
        console.log(newPropObj, 'newPropObj new object');
        this.submitCompletedTaskObj['StatusFlag'] = newPropObj;
        this.submitCompletedTaskObj['ArtComments'] = this.commentVal;

        console.log(this.submitCompletedTaskObj, 'new object');
        if (this.commentVal === '' || this.commentVal === undefined) {
            this.commentVal = '';
        } else {
            console.log(this.commentVal);
        }
        const ua = navigator.userAgent;
        const fileRealPath = document.getElementById('onFileUp')['value'];
        if (this.rForm.invalid) {
            const info = {
                browser: /Edge\/\d+/.test(ua) ? 'ed' : /MSIE 9/.test(ua) ? 'ie9' : /MSIE 10/.test(ua) ? 'ie10' : /MSIE 11/.test(ua) ? 'ie11' : /MSIE\s\d/.test(ua) ? 'ie?' : /rv\:11/.test(ua) ? 'ie11' : /Firefox\W\d/.test(ua) ? 'ff' : /Chrom(e|ium)\W\d|CriOS\W\d/.test(ua) ? 'gc' : /\bSafari\W\d/.test(ua) ? 'sa' : /\bOpera\W\d/.test(ua) ? 'op' : /\bOPR\W\d/i.test(ua) ? 'op' : typeof MSPointerEvent !== 'undefined' ? 'ie?' : '',
                os: /Windows NT 10/.test(ua) ? "win10" : /Windows NT 6\.0/.test(ua) ? "winvista" : /Windows NT 6\.1/.test(ua) ? "win7" : /Windows NT 6\.\d/.test(ua) ? "win8" : /Windows NT 5\.1/.test(ua) ? "winxp" : /Windows NT [1-5]\./.test(ua) ? "winnt" : /Mac/.test(ua) ? "mac" : /Linux/.test(ua) ? "linux" : /X11/.test(ua) ? "nix" : "",
                touch: 'ontouchstart' in document.documentElement,
                mobile: /IEMobile|Windows Phone|Lumia/i.test(ua) ? 'w' : /iPhone|iP[oa]d/.test(ua) ? 'i' : /Android/.test(ua) ? 'a' : /BlackBerry|PlayBook|BB10/.test(ua) ? 'b' : /Mobile Safari/.test(ua) ? 's' : /webOS|Mobile|Tablet|Opera Mini|\bCrMo\/|Opera Mobi/i.test(ua) ? 1 : 0,
                tablet: /Tablet|iPad/i.test(ua),
            };
            if (this.storeUpdatedVal === 'Complete' && this.rForm.value.upload != null) {
                this.onUpload();
                this._pass.submitJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe((data) => {
                    console.log(data, 'updateed data');
                });
                this.router.navigate(['dashboard']);
            } else if (info.browser === 'ed' && this.storeUpdatedVal === 'Complete' && this.rForm.value.upload === null) {
                console.log(this.rForm.value.upload, 'upload');
                this.rForm.value.upload = fileRealPath;
                console.log(this.rForm, 'Complete');
                this.onUpload();
                this._pass.submitJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe((data) => {
                    console.log(data, 'updateed data');
                });
                this.router.navigate(['dashboard'], this.navigationExtrasdash);
            } else {
                this.fileNotFoundServer = false;
                this.modalService.open(content);
                this.validateAllFormFields(this.rForm);
            }
        } else if (this.rForm.valid && (this.storeUpdatedVal === 'InComplete' || this.storeUpdatedVal === 'Hold')) {
            this.onUpload();
            this._pass.submitJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe((data) => {
                console.log(data, 'updateed data');
            });
            this.router.navigate(['dashboard']);
            console.log('form submitted');
        } else if (this.rForm.valid && this.storeUpdatedVal === 'Complete') {
            this.onUpload();
            this.router.navigate(['dashboard']);
            this._pass.submitJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe((data) => {
                console.log(data, 'updateed data');
            });
            console.log('form submitted');
        }
        this.journalLockStatus = false;
        this.hideForLockUser = true;
        this.fileNotFound = false;
        this.hideForSubmitJournal = false;
        this.statusAlreadyTaken = false;
        this.hideOkLockuser = false;
    }
    onUpload() {
        if (this.selectedFile !== undefined) {
            const body = {
                'Jcode': this.singleUserData['Jcode'],
                'ARTID': this.singleUserData['ARTID'],
                'TaskName': this.singleUserData['TaskName'],
                'ArtStatus': this.singleUserData['ArtStatus'],
            };
            const formData = new FormData();
            formData.append('file', this.selectedFile, this.selectedFile.name);
            formData.append('json', JSON.stringify(body));
            console.log(formData, 'uploadData');
            this._pass.uploadFileServer(this.valDecodeParameter, formData).subscribe({
                next: data => {
                    console.log(data, 'data');
                },
                error: error => {
                    console.log(error, 'error data');
                },
                complete: () => {
                    console.log('completed upload');
                }
            });
        }
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {
                this.validateAllFormFields(control);
            }
        });
    }

    lockUserData(content, e) {
        this.hideForSubmitJournal = true;
        this.statusAlreadyTaken = false;
        this.fileNotFoundServer = false;
        this.modalService.open(content);
        this.journalLockStatus = true;
        this.hideForLockUser = false;
        this.hideSaveJobAlreadyTaken = false;
        this.hideOkLockuser = true;
        if (e.target.checked) {
            localStorage.setItem('countLock', 'true');
            this.checkIfOthersAreSelected = true;
        }
    }
    okDataSave(e, content) {
        if (e.type === 'click') {
            this.submitCompletedTaskObj['StatusFlag'] = 0;
            console.log(this.submitCompletedTaskObj, 'this.submitCompletedTaskObj');
            this._pass.lockJournalForm(this.valDecodeParameter, this.submitCompletedTaskObj).subscribe((data) => {
                this.showLockUserResponse = data;
                this.modalService.open(content);
                this.statusAlreadyTaken = true;
                this.journalLockStatus = false;
                this.hideForSubmitJournal = false;
                this.fileNotFoundServer = false;
                localStorage.setItem('lockuser', 'true');
                this.userGotLocked = true;
            });
            console.log('e');
        }
        const lockUserName = localStorage.getItem('lockuser');
        if (lockUserName) {
            const unCheckLockUser = <HTMLInputElement>document.getElementById('changelock');
            unCheckLockUser.checked = true;
        }
        this.hideSaveJobAlreadyTaken = true;
        this.hideOkLockuser = false;
    }
    cancelDataSave(e) {
        if (e.type === 'click') {
            const unCheckLockUser = <HTMLInputElement>document.getElementById('changelock');
            if (unCheckLockUser.checked === true) {
                unCheckLockUser.checked = false;
            } else {
                unCheckLockUser.checked = true;
            }
        }
    }
    okHideDataSave($event, content) {
        this.hideSaveJobAlreadyTaken = false;
        this.hideSaveJobAlreadyTaken = true;
        this.fileNotFoundServer = false;
    }
    preeditingOnly(e) {
        if (e.target.checked) {
            this.checkedOrNot = 0;
        } else {
            this.checkedOrNot = 1;
        }
    }

    checkForError(val, content) {
        console.log(val, this.downloadNoContentDisposition, 'val download');
        if (val === 'download' && this.downloadNoContentDisposition === null) {
            this.journalLockStatus = false;
            this.statusAlreadyTaken = false;
            this.fileNotFound = false;
            this.hideForLockUser = false;
            this.hideForSubmitJournal = false;
            this.fileNotFoundServer = true;
            this.hideOkLockuser = false;
            this.modalService.open(content);
        } else if (val === 'style' && this.styleNoContentDisposition === null) {
            this.journalLockStatus = false;
            this.statusAlreadyTaken = false;
            this.fileNotFound = false;
            this.hideForLockUser = false;
            this.hideForSubmitJournal = false;
            this.fileNotFoundServer = true;
            this.hideOkLockuser = false;
            this.modalService.open(content);
        } else if (val === 'reference' && this.referenceNoContentDisposition === null) {
            this.journalLockStatus = false;
            this.statusAlreadyTaken = false;
            this.fileNotFound = false;
            this.hideForLockUser = false;
            this.hideForSubmitJournal = false;
            this.fileNotFoundServer = true;
            this.hideOkLockuser = false;
            this.modalService.open(content);
        }
    }
}


