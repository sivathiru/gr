import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from 'angular-6-datatable';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxSpinnerModule } from 'ngx-spinner';
import { CommonModule } from '@angular/common';
import { HashLocationStrategy, LocationStrategy, PathLocationStrategy, APP_BASE_HREF } from '@angular/common';
// import { SharedModule } from './shared.module';

// Routes
import { AppRoutingModule } from './app.routing-module';
import { AppComponent } from './app.component';
import { LoginService } from './login.service';
import { DashboardService } from './dashboard.service';
import { TaskService } from './task.service';

import { HeaderComponent } from './header/header.component';
import { MenuComponent } from './header/menu/menu.component';
import { AuthenticationComponent } from './authentication/authentication.component';
// import { DatafilterPipe } from './datafilter.pipe';
// import { ErrorComponent } from './task/error/error.component';
import { ReportsComponent } from './reports/reports.component';
import { CookieService } from 'ngx-cookie-service';
import { CommonUserAccess } from './common.service';

import { httpInterceptorProviders } from './http-interceptors/index';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MenuComponent,
    AuthenticationComponent,
   // DatafilterPipe,
    // ErrorComponent,
    ReportsComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    ToastrModule,
    ToastrModule.forRoot(),
    HttpModule,
    HttpClientModule,
    NgbModule,
    DataTableModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
//    SharedModule
  ],
  providers: [
    LoginService,
    DashboardService,
    TaskService,
    CookieService,
    CommonUserAccess,
    {provide: LocationStrategy, useClass: HashLocationStrategy},
    httpInterceptorProviders
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
