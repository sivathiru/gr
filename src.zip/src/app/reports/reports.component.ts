import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  historyTitles;
  historyData;
  anyDataHistory;
  closeResult: string;
  constructor(private _pass: TaskService, private modalService: NgbModal) {}

  ngOnInit() {
    this._pass.sampleDataPe().subscribe(arg => {
      const saveArtJson = arg;
      this.historyTitles = saveArtJson['ARTICLE_JSON_TITLE'];
      this.historyData = saveArtJson['ARTICLE_JSON_VALUE'];
  });
  }

}
