import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { Base64 } from 'js-base64';
import { ActivatedRoute, Params, Router, NavigationExtras } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  unsubscribeUserDashData;
  userAuthFullDetail;
  userAuthenticationDetail;
  pushTabList: any = [] ;
  valDecodeParameter;
  authEncodeParams;
  parseAuthEncoded;
  subscribeUserDashData;
  public displayArticleListing: any;
  initialStateData;
  userEncodedData;
  fullUserEncodeddata;
  singleListDataitems;
  articleTask;
  public rowsOnPage = 5;
  value: any;

  constructor(
    public _dash: DashboardService,
    private route: ActivatedRoute,
    public router: Router,
    private cookieService: CookieService,
    private spinner: NgxSpinnerService,
    protected _auth: LoginService,
    ) { }

  ngOnInit() {
    this.value = this.cookieService.get('token');
    this.spinner.show();
    this.unsubscribeUserDashData = this._dash.getProjectList(this.value).subscribe({
      next: data => {
          this.userAuthFullDetail = data;
          this.userAuthenticationDetail = data['GetJobDetails'];
          JSON.parse(this.userAuthenticationDetail).forEach(arr => {
              this.pushTabList.push(arr['name']);
          });
          this.sendOuterdetails(this.userAuthFullDetail);
      },
      error: err => {
          console.log(err);
      },
      complete: () => {
        this.spinner.hide();
          console.log('success');
      }
  });
  }

  sendOuterdetails(data) {
    this.subscribeUserDashData = this._dash.userDashData(data, this.value).subscribe(res => {
        this.displayArticleListing = res;
        console.log(this.displayArticleListing, 'this.displayArticleListing');
    });
}

singleArticlePages(item) {
    this.cookieService.set('singleArt', JSON.stringify(item));
  this.initialStateData = {
      ARTID: item.ARTID,
      ArtComments: item.ArtComments,
      ArtStatus: item.ArtStatus,
      Date_Assign: item.Date_Assign,
      Date_Complete: item.Date_Complete,
      Jcode: item.Jcode,
      MSPages: item.MSPages,
      TaskID: item.TaskID,
      TaskName: item.TaskName,
      Username: item.Username,
      Workname: item.Workname
  };

  this.userEncodedData = {
      ARTID: item.ARTID,
      ArtComments: item.ArtComments,
      ArtStatus: item.ArtStatus,
      Date_Assign: item.Date_Assign,
      Date_Complete: item.Date_Complete,
      Jcode: item.Jcode,
      MSPages: item.MSPages,
      TaskID: item.TaskID,
      TaskName: item.TaskName,
      Username: item.Username,
      Workname: item.Workname
  };

  this.userEncodedData = Base64.encode(JSON.stringify(this.userEncodedData));
  const userRawData = this.userEncodedData;
  this.fullUserEncodeddata = Base64.encode(`${item.TaskID}`);
  this.singleListDataitems = {
      autho0: this.valDecodeParameter,
      tkid: userRawData
  };

  this.articleTask = true;
  this.router.navigate(['task']);
}

projectNameList(e) {
    console.log(e, 'task id');
}
}
