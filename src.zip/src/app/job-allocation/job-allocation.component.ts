import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { DatafilterPipe } from '../datafilter.pipe';
import { JobAllocationService } from './job-allocation.service';
import { DashboardService } from '../dashboard.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-job-allocation',
  templateUrl: './job-allocation.component.html',
  styleUrls: ['./job-allocation.component.css'],
})
export class JobAllocationComponent implements OnInit {

   projects: string[] = ['Copyediting', 'PreEditing', 'JE'];
   journals: string[] = ['6598798', '6598745', '6598798'];
   dateCounts: string[] = ['12-10-2018'];
   UserPreEditing: string[] = [''];
   copyEditingUserList: string[] = [''];
   peerRevUserList: string[] = [''];

  jobForm;

  public jobList: any[];

  public data: any[];
    public jcodeQuery = '';
    public ArticleQuery = '';
    public rowsOnPage = 10;
    public sortBy = 'email';
    public sortOrder = 'asc';
    expandArticle;
   // toggleArticle = false;
   public projectNames: string;
   selectedItem;
   accessToken;
   showProjectList: Object;
   toggle = {};
   unsubscribeUserDashData;
   userAuthFullDetail;
   userAuthenticationDetail;
   pushTabList: any = [];
   copyEditorList: any;
   prefetchPreeditor: any;
   prefetchCopyeditor: any;
   prefetchPeerreview: any;
   count: any = 1;

  constructor(
    private http: HttpClient,
    private _dash: DashboardService,
    private _job: JobAllocationService,
    private _cookie: CookieService
    ) {}
  ngOnInit() {
    this.accessToken  = this._cookie.get('token');
    // get Project list call service
    this.unsubscribeUserDashData = this._dash.getProjectList(this.accessToken).subscribe({
      next: data => {
          this.userAuthFullDetail = data;
          console.log(this.userAuthFullDetail, 'data test');
          this.userAuthenticationDetail = data['GetJobDetails'];
          JSON.parse(this.userAuthenticationDetail).forEach(arr => {
             this.pushTabList.push(arr['name']);
          });
          this.showProjectList = {
            TaskName : data['User_Team'],
            Jcode : data['Id'],
            ArtId: data['ArticleId']
          };
          this.passProjectList(this.showProjectList);
          const showProjectListUser = {
            TaskName : data['User_Team'],
            Jcode : data['Id'],
            ArtId: data['ArticleId']
          };
          console.log(showProjectListUser, 'user data test');
      },
      error: err => {
          console.log(err);
      },
      complete: () => {
     //   this.spinner.hide();
          console.log('success');
      }
  });
  
  }

  // Listing  projects in job allocation page 
  passProjectList(data) {
    console.log(data, 'df');
    this._job.getAllocationList(data).subscribe(res => {
      this.data = res;
      console.log(this.data, 'getallocationlist');
    });
  }
  expandFormSubmit() {
    console.log(this.jobForm, 'r');
  }
  public toInt(num: string) {
    return +num;
  }
  public onChangeObj(e) {
    console.log(e, 'e');
  }

  public sortByWordLength = (a: any) => {
      return a.city.length;
  }

  // Expanding Article Rows by click 'plus'
  public expandingArticle(index, item, list) {
  // this.count += this.count + 1;
  // console.log(this.count, item, list, 'list item');
    index.style.display = (index.style.display === 'table-row') ? 'none' : 'table-row';
    index.style.backgroundColor = (index.style.backgroundColor === '#d9dcd9') ? 'red' : '#d9dcd9';
  //  if(list){
  //   this.prefetchPreeditor = item['Preediting'];
  //   this.prefetchCopyeditor = item['Copyediting'];
  //   this.prefetchPeerreview = item['Peerreview'];
  //    console.log(this.prefetchPreeditor, 'this.prefetchPeerreview item');
  //    console.log(this.prefetchCopyeditor, 'this.prefetchPeerreview item');
  //    console.log(this.prefetchPeerreview, 'this.prefetchPeerreview item');
  //   }
      this.getPreEditData(item);
  }

  public projectNameList(tab) {

  }

  // get Copy Editor list call service
  public getPreEditData(val) {
console.log(val, 'val');
    // console.log(val, 'event list item');
    if (val['Preediting'] === '' || val['Copyediting'] === '' || val['Peerreview'] === '' ) {
      this._job.getCopyEditorList(this.showProjectList).subscribe({
        next: (data) => {
          this.copyEditorList = data;
          console.log(this.copyEditorList, 'this.copyEditorList');
        },
        error: error => {
          console.log(error);
        },
        complete: () => {
          console.log('request completed');
        }
      });
    } else {
      console.log('no assignee');
    }

    // this.jobForm = new FormGroup({
    //   itemPreediting: new FormControl(''),
    //   itemCopyediting: new FormControl(''),
    //   itemPeerreview: new FormControl(''),
    //   itemComments: new FormControl(''),
    //   // dueTo: new FormControl(''),
    //   // preEditingName:  new FormControl(''),
    //   // copyEditingUser: new FormControl(''),
    //   // peerRevUser: new FormControl('')
    // });
  }

  // changes in editors in service call
  // public itemChanged() {

  // }
}

