import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSpinnerModule } from 'ngx-spinner';

import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard.routing-module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from 'angular-6-datatable';
// import { DataTableModule } from 'angular-6-datatable';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    NgbModule,
    DataTableModule,
    NgxSpinnerModule
  ],
  declarations: [DashboardComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DashboardModule { }

