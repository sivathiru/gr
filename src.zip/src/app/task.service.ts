import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest, HttpResponse, HttpEvent, HttpEventType, HttpInterceptor, HttpHandler } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { Observable, Subject, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  constructor(private _http: HttpClient) {}
  public userPassDashData(token, taskId: string): Observable<Object> {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`
        })
    };
    const body = {
        'TaskID' : taskId['TaskID']
    };
    const url = `${environment.serviceURL_HOPE}GetArtHistory`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
 }
 public uploadFileServer(param1, param2) {
     const flag: Boolean = false;
       const httpOptions = {
    headers: new HttpHeaders({
        'authorization': `bearer ${param1['access_token']}`,
        'Accept': 'text/plain'
    }),
  };

   const url = `${environment.serviceURL_HOPE}UploadFiles`;
   return this._http.post(url, param2, httpOptions);
 }

 private getEventMessage(event: HttpEvent<any>, file: File) {
    switch (event.type) {
      case HttpEventType.Sent:
        return `Uploading file "${file.name}" of size ${file.size}.`;

      case HttpEventType.UploadProgress:
        // Compute and show the % done:
        const percentDone = Math.round(100 * event.loaded / event.total);
        return `File "${file.name}" is ${percentDone}% uploaded.`;
      case HttpEventType.Response:
        return `File "${file.name}" was completely uploaded!`;
      default:
        return `File "${file.name}" surprising upload event: ${event.type}.`;
    }
  }
 public submitJournalForm(token, StatusUpdate) {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`
        }),
    };
    const body = StatusUpdate;
    const url = `${environment.serviceURL_HOPE}StatusUpdate`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
}
public lockJournalForm(token, status) {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`
        })
    };
    const body = status;
    const url = `${environment.serviceURL_HOPE}StatusUpdate`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
}

public downloadJournalForm(down, token): Observable<any>  {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`,
        }),
        responseType:  'blob' as 'json',
        observe: 'response' as 'body'
    };

    const body = down;
    const url = `${environment.serviceURL_HOPE}GetFile`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
}

public styleJournalForm(down, token): Observable<any>  {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`,
        }),
        responseType:  'blob' as 'json',
        observe: 'response' as 'body'
    };

    const body = down;
    const url = `${environment.serviceURL_HOPE}GetStyle`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
}
public referenceJournalForm(down, token): Observable<any>  {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`,
        }),
        responseType:  'blob' as 'json',
        observe: 'response' as 'body'
    };

    const body = down;
    const url = `${environment.serviceURL_HOPE}GetReference`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
}


public sampleDataPe() {
  return this._http.get(`assets/proxy.json`);
}

public specialInstruction(token, instruction) {
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${token['access_token']}`,
        })
    };

    const body = instruction;
    const url = `${environment.serviceURL_HOPE}FetchJRNL_Instructions`;
    return this._http.post(url, JSON.stringify(body), httpOptions);
}
}
