import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticationComponent } from './authentication/authentication.component';
import { TaskComponent } from './task/task.component';
import { JobAllocationComponent } from './job-allocation/job-allocation.component';
import { ReportsComponent } from './reports/reports.component';

const AppRoutes: Routes = [
    { path: 'login',
    component: AuthenticationComponent
    },
    { path: 'dashboard',
    loadChildren: './dashboard/dashboard.module#DashboardModule'
    },
    { path: 'task',
    loadChildren: './task/task.module#TaskModule'
    },
    { path: 'job_allocation',
    loadChildren: './job-allocation/job-allocation.module#JobAllocationModule'
    },
    { path: 'reports', component: ReportsComponent },
    { path: '', redirectTo: 'login',  pathMatch: 'full' },
];

@NgModule({
    imports: [
      RouterModule.forRoot(AppRoutes)
    ],
    exports: [RouterModule],
    providers: []
  })
export class AppRoutingModule { }
