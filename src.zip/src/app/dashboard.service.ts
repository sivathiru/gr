import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { Observable, Subject, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private _http: HttpClient) { }
  public getProjectList(userEncodedData: string) {
    const jsonDataParse = JSON.parse(userEncodedData);
    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'authorization': `bearer ${jsonDataParse['access_token']}`
        })
    };
    const body = `${jsonDataParse['UserName']}`;
    const url = `${environment.serviceURL_HOPE}GetProjectList`;

    return this._http.post(url, JSON.stringify(body), httpOptions)
    .pipe(map((Response: any) => Response), catchError(error => this.onError(error)));
}
onError(res: Response) {
      const statusCode = res.status;
      const body = res.json();
      const error = {
        statusCode: statusCode,
        error: body
      };
      return throwError(error);
    }

    public userDashData(getLocalUser, auth): Observable<Object> {
console.log(getLocalUser, auth, 'getLocalUser, userAccess');
      const accessUserData = JSON.parse(auth);
      const httpOptions = {
          headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'authorization': `bearer ${accessUserData['access_token']}`
          })
      };
      const body = {
          'Username' : getLocalUser['User_Name'],
          'Taskname' : getLocalUser['User_Team']
      };
      const url = `${environment.serviceURL_HOPE}GetTaskbyUser`;
      return this._http.post(url, JSON.stringify(body), httpOptions);
   }
}
