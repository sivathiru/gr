import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();


  constructor(private _http: HttpClient, private router: Router, private toastrService: ToastrService) { }
  public authenticateUser(userEncodedData: string): Observable<any> {
    console.log(userEncodedData, 'userEncodedData');
    this.getLoggedInName.emit(userEncodedData);
    const httpOptions = {
      headers: new HttpHeaders({
          'Content-Type': 'json',
      })
  };
   const body = `username=${userEncodedData['userName']}&password=${userEncodedData['password']}&grant_type=password`;
   const url = `${environment.serviceURL_HOPE}login`;

   return this._http.post(url, body, httpOptions);
  }
  onError(res: Response) {
    this.router.navigate(['login']);
      const statusCode = res.status;
      const body = res.json();
      const error = {
        statusCode: statusCode,
        error: body
      };
      return throwError(error);
    }
  }

