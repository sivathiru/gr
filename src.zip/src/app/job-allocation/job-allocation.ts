export interface JobAllocation {
  Jcode: string;
  ARTID: string;
  ArtStatus: string;
  DueDate: string;
}
