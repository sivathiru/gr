import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { Observable, Subject, throwError } from 'rxjs';
import { JobAllocation } from './job-allocation';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class JobAllocationService {
  accessToken;
  constructor(private _http: HttpClient, private _cookie: CookieService) { 
    this.accessToken  = JSON.parse(this._cookie.get('token'));
  }
  public getAllocationList(jobList): Observable<JobAllocation[]> {
    console.log(this.accessToken, 'this.accessToken');
    const body: Object = jobList;
    const url = `${environment.serviceURL_HOPE}GetAllocationList`;
    const httpsOption = {
      headers : new HttpHeaders({
        'Content-Type': 'application/json',
        'authorization': `bearer ${this.accessToken['access_token']}`
      })
    };
    return this._http.post<JobAllocation[]>(url, JSON.stringify(body), httpsOption);
  }

  public getCopyEditorList(pname): Observable<JobAllocation[]> {
    const body: string = pname['TaskName'];
    const url = `${environment.serviceURL_HOPE}GetUserList`;
    const httpsOption = {
      headers : new HttpHeaders({
        'Content-Type': 'application/json',
        'authorization': `bearer ${this.accessToken['access_token']}`
      })
    };
    console.log(url, JSON.stringify(body), httpsOption);
    return this._http.post<JobAllocation[]>(url, JSON.stringify(body), httpsOption);
  }

}
