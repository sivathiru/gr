import { Component, OnInit } from '@angular/core';
import { MenuComponent } from './menu/menu.component';
import { CookieService } from 'ngx-cookie-service';
import {Router, ActivatedRoute} from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  showLoginUser;
  storeToken;
  subAuthUser: string;
 // getHeaderName;
  constructor(
    private cookieservice: CookieService,
    public router: Router,
    private _auth: LoginService
    ) {
      this._auth.getLoggedInName.subscribe(name => this.changeName(name));
    }
  ngOnInit() {
    this.storeToken = JSON.parse(this.cookieservice.get('token'));
    this.showLoginUser = this.storeToken['UserName'];
    this.subAuthUser = this.showLoginUser;
  }
  logoutArticle() {
    this.cookieservice.delete('token');
    this.router.navigate(['login']);
  }
  private changeName(name: string): void {
    this.subAuthUser = name['userName'];
    console.log(this.subAuthUser, 'ewr');
}
}
