import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSpinnerModule } from 'ngx-spinner';
// import { DatafilterPipe } from '../datafilter.pipe';
import { SharedModule } from '../shared.module';

import { JobAllocationRoutingModule } from './job-allocation.routing-module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTableModule } from 'angular-6-datatable';
import { JobAllocationComponent } from './job-allocation.component';

@NgModule({
  imports: [
    CommonModule,
    JobAllocationRoutingModule,
    NgbModule,
    DataTableModule,
    ReactiveFormsModule,
    FormsModule,
    NgxSpinnerModule,
    SharedModule
  ],
  declarations: [JobAllocationComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class JobAllocationModule { }

