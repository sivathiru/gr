import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Params, Router, NavigationExtras } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoginService } from '../login.service';
import { Base64 } from 'js-base64';
import { Observable } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.css'],
})
export class AuthenticationComponent implements OnInit {
  profileForm = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
});
subAuthUser;
accessToken: Object;
AuthorisedUser: string;
// testerid: Boolean = true;
// tester: Boolean = true;
  constructor(
      protected _auth: LoginService,
      public route: ActivatedRoute,
      public router: Router,
      public toastrService: ToastrService,
      public spinner: NgxSpinnerService,
      config: NgbModalConfig,
      private modalService: NgbModal,
      private cookieService: CookieService
  ) { }

  ngOnInit() {
    this.spinner.show();
    setTimeout(() => {
        this.spinner.hide();
    }, 1000);
  }
  onSubmit(content) {
    const userEncodedData = this.profileForm.value;
    this.subAuthUser = this._auth.authenticateUser(userEncodedData).subscribe({
      next: data => {
        this.accessToken = data['access_token'];
        this.AuthorisedUser = data['UserName'];
        const authenticatedObject = JSON.stringify(data);
        this.cookieService.set( 'token', authenticatedObject );
        this.router.navigate(['dashboard']);
      },
      error: err => {
      //  this.modalService.open(err.message);
        console.log(err);
      },
      complete: () => console.log('completed login')
    });
  }
}


