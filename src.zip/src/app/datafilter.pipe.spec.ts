import { DatafilterPipe } from './datafilter.pipe';

describe('DatafilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DatafilterPipe();
    expect(pipe).toBeTruthy();
  });
});
