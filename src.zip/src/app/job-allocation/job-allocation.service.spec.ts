import { TestBed } from '@angular/core/testing';

import { JobAllocationService } from './job-allocation.service';

describe('JobAllocationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: JobAllocationService = TestBed.get(JobAllocationService);
    expect(service).toBeTruthy();
  });
});
