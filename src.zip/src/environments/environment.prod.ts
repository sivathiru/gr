export const environment = {
  production: true,
  serviceURL_HOPE: 'http://eproof.hurix.com/hope_webapi/',
};
