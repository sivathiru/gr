import { Component, OnInit } from '@angular/core';
import { Params, Router, NavigationExtras } from '@angular/router';
import { Base64 } from 'js-base64';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(
    private router: Router,
    ) { }

  ngOnInit() {
  }
  public routeToDashboard() {
    this.router.navigate(['dashboard']);
  }
  public allocateJob() {
      this.router.navigate(['job_allocation']);
  }
  public liveReport() {
      this.router.navigate(['reports']);
  }
}
