import * as _ from 'lodash';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dataFilter'
})
export class DatafilterPipe implements PipeTransform {

  transform(array: any[], jcodeQuery: string, ArticleQuery: string): any {
    if (array && array.length) {
      return array.filter(item => {
        if (jcodeQuery && item.Jcode.toLowerCase().indexOf(jcodeQuery.toLowerCase()) === -1) {
          return false;
        }
        if (ArticleQuery && item.ARTID.toLowerCase().indexOf(ArticleQuery.toLowerCase()) === -1) {
            return false;
        }
        return true;
      });
    } else {
      return array;
  }
    // if (query) {
    //     return _.filter(array, row => row.Jcode.indexOf(query) > -1);
    // }
    // return array;
  }
}
