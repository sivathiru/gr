import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DatafilterPipe } from './datafilter.pipe';

@NgModule({
  imports: [
  ],
  declarations: [
    DatafilterPipe
  ],
  exports: [
    DatafilterPipe
  ]
})

export class SharedModule { }