import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType, HttpHeaderResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable()

export class CommonUserAccess {
constructor(private _http: HttpClient) {}

/**
 * commonUserAccess
 */
public commonUserAccess() {
    return this._http.get(`assets/proxy.json`);
}
}
