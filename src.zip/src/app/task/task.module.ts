import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSpinnerModule } from 'ngx-spinner';
// import { DatafilterPipe } from '../datafilter.pipe';
import { SharedModule } from '../shared.module';

import { TaskRoutingModule } from './task.routing-module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DataTableModule } from 'angular-6-datatable';
import { TaskComponent } from '../task/task.component';
import { ErrorComponent } from './error/error.component';

@NgModule({
  imports: [
    CommonModule,
    TaskRoutingModule,
    NgbModule,
    DataTableModule,
    ReactiveFormsModule,
    FormsModule,
    NgxSpinnerModule,
    SharedModule
  ],
  declarations: [TaskComponent, ErrorComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TaskModule { }

